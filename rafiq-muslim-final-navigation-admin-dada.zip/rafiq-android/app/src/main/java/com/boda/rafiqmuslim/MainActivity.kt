package com.boda.rafiqmuslim

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import android.widget.LinearLayout
import android.view.View
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import androidx.activity.ComponentActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import java.util.Calendar
import java.net.URL
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var bannerAd: AdView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        requestRuntimePermissions()
        askExactAlarmPermissionIfNeeded()
        MobileAds.initialize(this) {}
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = WebChromeClient()
        val dataRoot = File(getExternalFilesDir(null) ?: filesDir, "Dada").apply { if (!exists()) mkdirs() }
        File(dataRoot, "الأذان").apply { if (!exists()) mkdirs() }
        val quranDir = File(filesDir, "quran").apply { if (!exists()) mkdirs() }
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/quran/", WebViewAssetLoader.InternalStoragePathHandler(this, quranDir))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url) ?: super.shouldInterceptRequest(view, request)
            }
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val ad = AdView(this).apply {
            setAdSize(AdSize.BANNER)
            // Google test banner ID. Replace with your approved AdMob ad unit ID before release.
            adUnitId = "ca-app-pub-3940256099942544/6300978111"
            visibility = View.GONE
            loadAd(AdRequest.Builder().build())
        }
        bannerAd = ad
        web.addJavascriptInterface(PrayerBridge(this, { visible ->
            runOnUiThread { bannerAd?.visibility = if (visible) View.VISIBLE else View.GONE }
        }, { success, message ->
            runOnUiThread { web.evaluateJavascript("if(window.onAthanDownloadFinished)window.onAthanDownloadFinished($success,${JSONObject.quote(message)});", null) }
        }, { url, success, message ->
            runOnUiThread { web.evaluateJavascript("if(window.onAthanVoiceDownloadFinished)window.onAthanVoiceDownloadFinished(${JSONObject.quote(url)},$success,${JSONObject.quote(message)});", null) }
        }), "AndroidPrayer")
        web.addJavascriptInterface(QuranDownloadBridge(this, web), "AndroidQuran")
        root.addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(ad, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private fun askExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) } catch (_: Exception) { }
            }
        }
    }

    override fun onResume() { super.onResume(); bannerAd?.resume(); if (::web.isInitialized) web.post { web.evaluateJavascript("if(window.updateNotificationPermission)window.updateNotificationPermission();", null) } }
    override fun onPause() { bannerAd?.pause(); super.onPause() }
    override fun onDestroy() { bannerAd?.destroy(); bannerAd = null; super.onDestroy() }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}

class PrayerBridge(private val context: Context, private val adVisibility: (Boolean) -> Unit = {}, private val athanResult: (Boolean, String) -> Unit = { _, _ -> }, private val athanVoiceResult: (String, Boolean, String) -> Unit = { _, _, _ -> }) {
    @JavascriptInterface
    fun setAdVisible(visible: Boolean) { adVisibility(visible) }
    private fun athanDirectory(): File = File(context.getExternalFilesDir(null) ?: context.filesDir, "Dada/الأذان").apply { if (!exists()) mkdirs() }
    private fun athanKey(url: String): String = java.security.MessageDigest.getInstance("SHA-256").digest(url.toByteArray()).joinToString("") { "%02x".format(it) }.take(24)
    private fun athanFile(url: String): File = File(athanDirectory(), "${athanKey(url)}.mp3")

    @JavascriptInterface
    fun setAthanVoice(name: String, url: String) {
        try {
            val parsed = Uri.parse(url)
            val allowed = parsed.scheme == "https" && (parsed.host == "d1.islamhouse.com" || parsed.host == "www.islamcan.com")
            if (!allowed) return
            val file = athanFile(url)
            context.getSharedPreferences("prayer_schedule", Context.MODE_PRIVATE).edit()
                .putString("athan_voice_name", name.take(100))
                .putString("athan_voice_url", url)
                .putString("athan_file", if (file.exists() && file.length() > 1024) file.absolutePath else null)
                .putString("athan_downloaded_url", if (file.exists() && file.length() > 1024) url else null)
                .apply()
        } catch (_: Exception) { }
    }

    @JavascriptInterface
    fun isAthanVoiceDownloaded(url: String): Boolean = try { athanFile(url).let { it.exists() && it.length() > 1024 } } catch (_: Exception) { false }

    @JavascriptInterface
    fun hasAthanDownloaded(): Boolean {
        val prefs = context.getSharedPreferences("prayer_schedule", Context.MODE_PRIVATE)
        val url = prefs.getString("athan_voice_url", null) ?: return false
        return isAthanVoiceDownloaded(url)
    }

    @JavascriptInterface
    fun downloadAthanVoice(name: String, url: String) {
        try {
            val parsed = Uri.parse(url)
            val allowed = parsed.scheme == "https" && (parsed.host == "d1.islamhouse.com" || parsed.host == "www.islamcan.com")
            if (!allowed) { notifyAthanVoice(url, false, "مصدر ملف الأذان غير مسموح."); return }
            Thread {
                var ok = false
                var message = "تعذر تنزيل صوت الأذان. تحقق من الإنترنت ثم أعد المحاولة."
                val target = athanFile(url)
                val temp = File(target.parentFile, target.name + ".part")
                try {
                    if (target.exists() && target.length() > 1024) {
                        ok = true; message = "صوت هذا المؤذن محفوظ بالفعل داخل Dada/الأذان."
                    } else {
                        val connection = URL(url).openConnection().apply { connectTimeout = 20000; readTimeout = 60000; setRequestProperty("User-Agent", "RafiqMuslim/1.0") }
                        connection.getInputStream().use { input -> FileOutputStream(temp).use { output -> input.copyTo(output) } }
                        if (temp.length() < 1024) throw IllegalStateException("ملف الأذان غير مكتمل")
                        if (target.exists()) target.delete()
                        if (!temp.renameTo(target)) throw IllegalStateException("تعذر حفظ الملف")
                        ok = true; message = "تم تنزيل صوت ${name.take(80)} وحفظه في Dada/الأذان للعمل دون إنترنت."
                    }
                    if (ok) context.getSharedPreferences("prayer_schedule", Context.MODE_PRIVATE).edit()
                        .putString("athan_voice_name", name.take(100)).putString("athan_voice_url", url)
                        .putString("athan_file", target.absolutePath).putString("athan_downloaded_url", url).apply()
                } catch (_: Exception) { temp.delete() }
                notifyAthanVoice(url, ok, message)
                if (context.getSharedPreferences("prayer_schedule", Context.MODE_PRIVATE).getString("athan_voice_url", null) == url) notifyAthan(ok, message)
            }.start()
        } catch (_: Exception) { notifyAthanVoice(url, false, "تعذر بدء تنزيل الأذان.") }
    }

    private fun notifyAthanVoice(url: String, success: Boolean, message: String) {
        athanVoiceResult(url, success, message)
    }

    private fun notifyAthan(success: Boolean, message: String) {
        athanResult(success, message)
    }

    @JavascriptInterface
    fun areNotificationsEnabled(): Boolean = NotificationManagerCompat.from(context).areNotificationsEnabled()

    @JavascriptInterface
    fun openNotificationSettings() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= 26) Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: Exception) { }
    }

    @JavascriptInterface
    fun setPrayerTimes(json: String) {
        try {
            val obj = JSONObject(json)
            val names = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
            val prefs = context.getSharedPreferences("prayer_schedule", Context.MODE_PRIVATE)
            prefs.edit().putString("times", json).apply()
            val now = Calendar.getInstance()
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            names.forEachIndexed { index, name ->
                val raw = obj.optString(name, "")
                val parts = raw.split(":")
                if (parts.size != 2) return@forEachIndexed
                val hour = parts[0].toIntOrNull() ?: return@forEachIndexed
                val minute = parts[1].toIntOrNull() ?: return@forEachIndexed
                val whenAt = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
                }
                val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                    putExtra("prayer", name)
                    action = "com.boda.rafiqmuslim.PRAYER_$name"
                }
                val pi = android.app.PendingIntent.getBroadcast(context, index + 100, intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
                if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt.timeInMillis, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, whenAt.timeInMillis, pi)
            }
        } catch (_: Exception) { }
    }
}


class QuranDownloadBridge(private val context: Context, private val web: WebView) {
    private fun quranDirectory(): File = File(context.getExternalFilesDir(null) ?: context.filesDir, "Dada/القرآن الكريم").apply { if (!exists()) mkdirs() }
    private fun playbackDirectory(): File = File(context.filesDir, "quran").apply { if (!exists()) mkdirs() }
    private val allowedReciters = setOf("afs", "sds", "basit", "minsh")

    @JavascriptInterface
    fun isSurahDownloaded(surahNumber: Int, reciterKey: String): Boolean {
        if (surahNumber !in 1..114 || reciterKey !in allowedReciters) return false
        return File(quranDirectory(), String.format(java.util.Locale.US, "%03d-%s.mp3", surahNumber, reciterKey)).let { it.exists() && it.length() > 0 }
    }

    @JavascriptInterface
    fun downloadSurah(surahNumber: Int, reciterKey: String, reciterName: String, url: String) {
        if (surahNumber !in 1..114 || reciterKey !in allowedReciters) {
            notifyPage(surahNumber, reciterKey, false, "بيانات السورة غير صحيحة")
            return
        }
        val uri = Uri.parse(url)
        if (uri.scheme != "https" || uri.host?.endsWith("mp3quran.net") != true) {
            notifyPage(surahNumber, reciterKey, false, "مصدر الصوت غير مسموح")
            return
        }
        Thread {
            var success = false
            var message = "تعذر تنزيل السورة. تحقق من الإنترنت ومساحة الهاتف."
            try {
                val directory = quranDirectory()
                val target = File(directory, String.format(java.util.Locale.US, "%03d-%s.mp3", surahNumber, reciterKey))
                val connection = URL(url).openConnection().apply {
                    connectTimeout = 20000
                    readTimeout = 60000
                    setRequestProperty("User-Agent", "RafiqMuslim/1.0")
                }
                connection.getInputStream().use { input ->
                    val temp = File(directory, target.name + ".part")
                    FileOutputStream(temp).use { output -> input.copyTo(output) }
                    if (temp.length() < 1024) throw IllegalStateException("ملف الصوت غير مكتمل")
                    if (target.exists()) target.delete()
                    if (!temp.renameTo(target)) throw IllegalStateException("تعذر حفظ الملف")
                }
                val playbackCopy = File(playbackDirectory(), target.name)
                target.inputStream().use { input -> FileOutputStream(playbackCopy).use { output -> input.copyTo(output) } }
                success = true
                message = "تم تنزيل سورة ${surahNumber} بصوت ${reciterName.take(80)} وحفظها داخل Dada/القرآن الكريم"
            } catch (_: Exception) {
                File(quranDirectory(), String.format(java.util.Locale.US, "%03d-%s.mp3.part", surahNumber, reciterKey)).delete()
            }
            notifyPage(surahNumber, reciterKey, success, message)
        }.start()
    }

    private fun notifyPage(number: Int, key: String, success: Boolean, message: String) {
        val safeMessage = JSONObject.quote(message)
        web.post {
            web.evaluateJavascript("if(window.onSurahDownloaded)window.onSurahDownloaded($number,${JSONObject.quote(key)},$success,$safeMessage);", null)
        }
    }
}
