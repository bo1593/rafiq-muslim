package com.boda.rafiqmuslim

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prayer = intent.getStringExtra("prayer") ?: "الصلاة"
        val service = Intent(context, AthanService::class.java).putExtra("prayer", prayer)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service)
            else context.startService(service)
        } catch (_: Exception) { }
        // Re-arm all five alarms for their next daily occurrence.
        val saved = context.getSharedPreferences("prayer_schedule", Context.MODE_PRIVATE).getString("times", null)
        if (saved != null) PrayerBridge(context).setPrayerTimes(saved)
    }
}
