package com.boda.rafiqmuslim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class AthanService : Service() {
    private var player: MediaPlayer? = null
    override fun onCreate() {
        super.onCreate()
        createChannel()
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prayer = intent?.getStringExtra("prayer") ?: "الصلاة"
        startForeground(7, notification(prayer))
        try {
            player?.release()
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                val prefs = getSharedPreferences("prayer_schedule", MODE_PRIVATE)
                val voiceUrl = prefs.getString("athan_voice_url", "https://www.islamcan.com/audio/adhan/azan1.mp3")
                    ?: "https://www.islamcan.com/audio/adhan/azan1.mp3"
                val key = java.security.MessageDigest.getInstance("SHA-256").digest(voiceUrl.toByteArray()).joinToString("") { "%02x".format(it) }.take(24)
                val downloaded = java.io.File(getExternalFilesDir(null) ?: filesDir, "Dada/الأذان/$key.mp3")
                val offlinePath = prefs.getString("athan_file", null)
                if (downloaded.exists() && downloaded.length() > 1024) setDataSource(downloaded.absolutePath)
                else if (!offlinePath.isNullOrBlank() && java.io.File(offlinePath).exists() && java.io.File(offlinePath).length() > 1024) setDataSource(offlinePath)
                else setDataSource(voiceUrl)
                setOnPreparedListener { it.start() }
                setOnCompletionListener { stopSelf() }
                setOnErrorListener { _, _, _ -> stopSelf(); true }
                prepareAsync()
            }
        } catch (_: Exception) { stopSelf() }
        return START_NOT_STICKY
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("athan_channel", "أذان الصلاة", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "تشغيل الأذان في مواقيت الصلاة"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun notification(prayer: String): Notification = NotificationCompat.Builder(this, "athan_channel")
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle("حان وقت الصلاة")
        .setContentText("أذان صلاة $prayer - " + (getSharedPreferences("prayer_schedule", MODE_PRIVATE).getString("athan_voice_name", "المؤذن المختار") ?: "المؤذن المختار"))
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setCategory(NotificationCompat.CATEGORY_ALARM)
        .setOngoing(true).build()
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
