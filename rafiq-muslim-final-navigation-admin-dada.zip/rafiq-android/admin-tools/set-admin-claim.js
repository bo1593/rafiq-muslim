// امنح صلاحية الأدمن من بيئة موثوقة فقط (مثل Google Cloud Shell).
// يستخدم Application Default Credentials؛ لا يحتاج تنزيل Service Account JSON.
// لا ترفع هذا السكربت إلى استضافة عامة ولا تضع بيانات دخول داخله.
const admin = require('firebase-admin');

const uid = process.argv[2];
const projectId = process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT;

if (!uid) {
  throw new Error('Usage: node set-admin-claim.js FIREBASE_AUTH_UID');
}
if (!projectId) {
  throw new Error('Set GOOGLE_CLOUD_PROJECT to your Firebase project ID first.');
}

admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  projectId
});

(async () => {
  // Preserve any existing custom claims instead of overwriting them.
  const user = await admin.auth().getUser(uid);
  const existingClaims = user.customClaims || {};
  await admin.auth().setCustomUserClaims(uid, { ...existingClaims, admin: true });
  console.log(`Admin claim enabled for UID ${uid} in project ${projectId}.`);
  console.log('Sign out and sign in again, or force-refresh the ID token.');
})().catch((error) => {
  console.error('Could not set admin claim:', error.message);
  process.exitCode = 1;
});
